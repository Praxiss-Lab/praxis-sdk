# Praxis extensions snapshot

Owned package for the bundled skills, integration and automation catalogs.
The hosted OpenHands CLI plugin is excluded. Backend API helpers require an
explicit self-hosted URL and reject hosted vendor endpoints before authentication.
Configure model-provider credentials separately. Original plugin identifiers and
attributions remain for compatibility; copyright and LICENSE are preserved.

See https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md.
